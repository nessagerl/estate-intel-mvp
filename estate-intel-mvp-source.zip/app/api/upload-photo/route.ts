import { supabaseServer } from "@/lib/supabase-server";

export async function POST() {
  try {
    const photoId = crypto.randomUUID();
    const storagePath = `incoming/${photoId}`;

    const { data, error } = await supabaseServer.storage
      .from("investigation-photos")
      .createSignedUploadUrl(storagePath);

    if (error) {
      throw error;
    }

    return Response.json({
      success: true,
      storagePath,
      token: data.token,
    });
  } catch (error) {
    console.error("Upload authorization error:", error);

    return Response.json(
      {
        success: false,
        message: "Could not authorize photo upload.",
      },
      { status: 500 }
    );
  }
}